<?php
	$koneksi = mysqli_connect("localhost","root","1234","bukusaya");
?>
